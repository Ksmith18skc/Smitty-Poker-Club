// Sound URLs from a CDN or public assets
export const dealCardSound = 'https://cdn.example.com/sounds/deal-card.mp3';
export const chipSound = 'https://cdn.example.com/sounds/chip.mp3';
export const foldSound = 'https://cdn.example.com/sounds/fold.mp3';